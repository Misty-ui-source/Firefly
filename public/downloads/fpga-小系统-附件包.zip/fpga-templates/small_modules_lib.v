// =====================================================================
//  FPGA 小系统傻瓜模板库 (Verilog-2001)
//  用法: 每个模块只改 ★ 标记的参数, 内部结构不要改。
//  约定: 本库 rst 为高电平有效; 题目是 rst_n 低有效时, 例化时接 ~rst_n。
//  说明: 模板优先"写对", 计数器统一用 32 位宽, 不追求最省资源。
// =====================================================================

// ---------------------------------------------------------------------
// 模块1 边沿检测: din 延迟一拍, 与原信号相与得到单周期脉冲
// ★改: 无参数。btn 是几位就例化几次 (或对向量逐位写同样的两行)
// 出现: 题一 btn 上升沿切模式 / 题四 BTNC、BTNL 按下 / 题三 i_set 拉低
// ---------------------------------------------------------------------
module edge_detect (
    input  wire clk,
    input  wire rst,        // 高有效
    input  wire din,
    output wire pos_edge,   // 上升沿: 1 个 clk 的脉冲
    output wire neg_edge    // 下降沿: 1 个 clk 的脉冲
);
    reg din_d;
    always @(posedge clk or posedge rst) begin
        if (rst) din_d <= 1'b0;
        else     din_d <= din;
    end
    assign pos_edge =  din & ~din_d;
    assign neg_edge = ~din &  din_d;
endmodule

// ---------------------------------------------------------------------
// 模块2 两级同步 (只上板用, 纯仿真题不要加, 加了节拍对不上 TB)
// 出现: 题四上板时按键/开关进 FPGA 前先同步; 需要消抖时再在后面接
//       "计数器连续稳定 N 拍才认"的消抖, 仿真里 N 取小值即可
// ---------------------------------------------------------------------
module sync_2ff (
    input  wire clk,
    input  wire rst,
    input  wire din,
    output reg  dout
);
    reg din_s;
    always @(posedge clk or posedge rst) begin
        if (rst) begin din_s <= 1'b0; dout <= 1'b0; end
        else     begin din_s <= din;  dout <= din_s; end
    end
endmodule

// ---------------------------------------------------------------------
// 模块3 节拍发生器 tick: 每 N 个 clk 输出 1 个单周期脉冲
// ★改: N = 目标时间 x 时钟频率
//       例: 100MHz 下 200ns -> N=20; 0.1s -> N=10_000_000; 每 2 拍 -> N=2
// 出现: 题一闪烁 / 题三每 2(4) 拍点一格 / 题四 0.1s 流水间隔
// ---------------------------------------------------------------------
module tick_gen #(
    parameter N = 10
)(
    input  wire clk,
    input  wire rst,
    input  wire clr,        // 回到该状态/模式时清零, 保证相位确定
    input  wire en,         // 只在需要计时的状态里拉高
    output reg  tick
);
    reg [31:0] cnt;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            cnt <= 32'd0; tick <= 1'b0;
        end else if (clr) begin
            cnt <= 32'd0; tick <= 1'b0;
        end else if (en) begin
            if (cnt == N-1) begin cnt <= 32'd0; tick <= 1'b1; end
            else            begin cnt <= cnt + 1'b1; tick <= 1'b0; end
        end else begin
            tick <= 1'b0;
        end
    end
endmodule

// ---------------------------------------------------------------------
// 模块4 流水灯 (只有一个亮点在跑): 从高位向低位循环移位
// ★改: WIDTH 灯数; 方向反过来就把移位式左右对调
// 序列(WIDTH=4): 1000 -> 0100 -> 0010 -> 0001 -> 1000 ...
// 出现: 题一模式4 / 题三 PORRIDGE / 题四 S1 发射流水
// ---------------------------------------------------------------------
module led_flow #(
    parameter WIDTH = 4
)(
    input  wire             clk,
    input  wire             rst,
    input  wire             clr,  // 回到起始位 100..0
    input  wire             en,   // 每来一个 tick 移一位 (en 接 tick 或状态本身)
    output reg  [WIDTH-1:0] led
);
    localparam [WIDTH-1:0] START = {1'b1, {(WIDTH-1){1'b0}}};
    always @(posedge clk or posedge rst) begin
        if (rst)      led <= START;
        else if (clr) led <= START;
        else if (en)  led <= {led[0], led[WIDTH-1:1]};  // 右移并回绕
    end
endmodule

// ---------------------------------------------------------------------
// 模块5 进度条 (亮过的不灭): 从高位向低位逐格填 1
// 序列: 0000 -> 1000 -> 1100 -> 1110 -> 1111, 全亮后 done=1
// ★改: WIDTH 灯数
// 出现: 题三 RICE 做饭进度
// ---------------------------------------------------------------------
module led_progress #(
    parameter WIDTH = 4
)(
    input  wire             clk,
    input  wire             rst,
    input  wire             clr,
    input  wire             en,   // 每来一个 tick 填一格
    output reg  [WIDTH-1:0] led,
    output wire             done
);
    assign done = &led;                          // 全 1 即填满
    always @(posedge clk or posedge rst) begin
        if (rst)      led <= {WIDTH{1'b0}};
        else if (clr) led <= {WIDTH{1'b0}};
        else if (en)  led <= {1'b1, led[WIDTH-1:1]};  // 高位填 1, 其余右移
    end
endmodule

// ---------------------------------------------------------------------
// 模块6 置位-清除锁存: set 置 1, clr 清 0, 其余保持 (clr 优先)
// 出现: 题二 o_led 点亮后保持到 INIT / o_buzzer 报错后保持到 INIT
// ---------------------------------------------------------------------
module set_clear (
    input  wire clk,
    input  wire rst,
    input  wire set,
    input  wire clr,
    output reg  q
);
    always @(posedge clk or posedge rst) begin
        if (rst)      q <= 1'b0;
        else if (clr) q <= 1'b0;
        else if (set) q <= 1'b1;
    end
endmodule

// ---------------------------------------------------------------------
// 模块7 一次性定时: trig 后输出 N 个 clk, 自动停 (busy 期间忽略新 trig)
// ★改: N 输出时长(拍数)
// 出现: 题三蜂鸣器响 2 拍 / 题四每次发射只跑一轮流水
// ---------------------------------------------------------------------
module oneshot #(
    parameter N = 2
)(
    input  wire clk,
    input  wire rst,
    input  wire trig,
    output reg  busy,
    output wire out_pulse
);
    reg [31:0] cnt;
    assign out_pulse = busy;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            busy <= 1'b0; cnt <= 32'd0;
        end else if (!busy) begin
            if (trig) begin busy <= 1'b1; cnt <= 32'd0; end
        end else begin
            if (cnt == N-1) begin busy <= 1'b0; cnt <= 32'd0; end
            else cnt <= cnt + 1'b1;
        end
    end
endmodule

// ---------------------------------------------------------------------
// 模块8 模 M 可逆计数器 (回绕): up +1, down -1, 到头绕回另一头
// ★改: M 模数, W 位宽 (2^W >= M)
// 出现: 题一模式寄存器 (M=4: btn[1] 沿 +1, btn[0] 沿 -1)
// ---------------------------------------------------------------------
module updown_counter #(
    parameter M = 4,
    parameter W = 2
)(
    input  wire         clk,
    input  wire         rst,
    input  wire         up,
    input  wire         down,
    output reg  [W-1:0] value
);
    always @(posedge clk or posedge rst) begin
        if (rst) value <= {W{1'b0}};
        else if (up)
            value <= (value == M-1) ? {W{1'b0}} : value + 1'b1;
        else if (down)
            value <= (value == 0)   ? M-1       : value - 1'b1;
    end
endmodule

// ---------------------------------------------------------------------
// 模块9 组合加权计数: 数向量里等于 TARGET 的位数, 每位记 WEIGHT 分
// ★改: WIDTH 位数, WEIGHT 每位分值, TARGET 数 0 还是数 1
// 出现: 题四弩箭数 = 低电平开关数 x 4 (WIDTH=16, WEIGHT=4, TARGET=0)
// 注意: 状态内"只减不增"的要求不能用纯组合计数, 要改上升沿扣减, 见题四说明
// ---------------------------------------------------------------------
module popcount_weighted #(
    parameter WIDTH  = 16,
    parameter WEIGHT = 4,
    parameter TARGET = 0
)(
    input  wire [WIDTH-1:0] din,
    output reg  [7:0]       count
);
    integer i;
    always @(*) begin
        count = 8'd0;
        for (i = 0; i < WIDTH; i = i + 1)
            if (din[i] == (TARGET != 0)) count = count + WEIGHT;
    end
endmodule

// ---------------------------------------------------------------------
// 模块10 七段译码 (固定查表, 不用现编): seg[6]=a ... seg[0]=g, 高电平点亮
// 出现: 题四数码管显示箭数 (先用模块11把数值拆成十位/个位再各查一次)
// ---------------------------------------------------------------------
module seg7 (
    input  wire [3:0] digit,
    output reg  [6:0] seg
);
    always @(*) begin
        case (digit)
            4'd0: seg = 7'b1111110;
            4'd1: seg = 7'b0110000;
            4'd2: seg = 7'b1101101;
            4'd3: seg = 7'b1111001;
            4'd4: seg = 7'b0110011;
            4'd5: seg = 7'b1011011;
            4'd6: seg = 7'b1011111;
            4'd7: seg = 7'b1110000;
            4'd8: seg = 7'b1111111;
            4'd9: seg = 7'b1111011;
            default: seg = 7'b0000000;
        endcase
    end
endmodule

// ---------------------------------------------------------------------
// 模块11 二进制拆十位/个位 (小数值直接 /10 与 %10, 仿真综合都认)
// 值域要求 value < 100 (两位显示, 十位只留 4 位)
// 出现: 题四箭数 0~64 两位显示
// ---------------------------------------------------------------------
module bin_to_tens_ones (
    input  wire [7:0] value,
    output wire [3:0] tens,
    output wire [3:0] ones
);
    assign tens = value / 10;
    assign ones = value % 10;
endmodule
