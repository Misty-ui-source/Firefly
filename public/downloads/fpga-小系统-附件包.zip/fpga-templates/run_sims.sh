#!/usr/bin/env bash
# 一键跑全部自测仿真: bash run_sims.sh
# 仿真器优先级: 持久安装 (workspace/tools, 不会被系统清理) > PATH 里的 iverilog > /tmp 临时安装
set -u
cd "$(dirname "$0")"
IV=""
for c in "$HOME/workspace/tools/iverilog-env/bin/iverilog" "$(command -v iverilog || true)" "/tmp/iverilog-env/bin/iverilog"; do
    if [ -n "$c" ] && [ -x "$c" ]; then IV="$c"; break; fi
done
if [ -z "$IV" ]; then echo "找不到 iverilog, 先看 README 里的安装说明"; exit 1; fi
VVP="$(dirname "$IV")/vvp"
echo "使用仿真器: $IV"
OUT="$(mktemp -d)"
fail=0
run() {  # $1=名字 $2=tb $3..=源文件
    local name="$1"; shift
    if "$IV" -o "$OUT/$name" "$@" && "$VVP" "$OUT/$name" | grep -q "ALL PASS"; then
        echo "PASS $name"
    else
        echo "FAIL $name (手动跑对应 TB 看详情)"; fail=1
    fi
}
run tb_lib    tb/tb_buzzer.v  buzzer_special.v
run tb_q1     tb/tb_q1.v      q1_led_control.v
run tb_q2     tb/tb_q2.v      q2_boot_fsm.v
run tb_q3     tb/tb_q3.v      q3_rice_cooker.v
# 模板库与全部文件一起编译 (查语法与重名)
"$IV" -o "$OUT/all" small_modules_lib.v buzzer_special.v q1_led_control.v q2_boot_fsm.v q3_rice_cooker.v \
    && echo "PASS all-compile" || { echo "FAIL all-compile"; fail=1; }
rm -rf "$OUT"
exit $fail
