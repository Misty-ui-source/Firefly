// =====================================================================
// 蜂鸣器专题 (单独一期): 考试里的蜂鸣器其实有四种打法, 先查表选型
//
// ★★★ 选型表 (先定打法, 再抄对应模块) ★★★
//  题目说法                              打法         模块
//  报错就响, 一直响到复位/回 INIT 才停   置位-清除锁存 buzzer_alarm   (题二)
//  响 N 拍就停, 停后还要打印/做下一步    一次性+done buzzer_beep    (题三)
//  响 K 声, 每声之间有间隔               小状态机     buzzer_beeps   (扩展)
//  上板接无源蜂鸣器, 给高电平也不响      音调方波     buzzer_tone    (上板)
//
// 约定: 本文件 rst 高电平有效 (题目 rst_n 低有效时例化接 ~rst_n);
//       仿真题的蜂鸣器都是"有源"模型: 输出高电平 = 在响, 不用管频率;
//       buzzer_tone 只在真上板且蜂鸣器是无源时才需要, 套在前三种的
//       输出电平后面: 引脚 = 响电平 ? tone_wave : 0 (见文件末组合图)
// =====================================================================

// ---------------------------------------------------------------------
// 打法1 buzzer_alarm: 置位-清除锁存 (和模板库 set_clear 是同一个东西)
// ★状态表 (只有两态):
//   OFF --set--> ON ; ON --clr--> OFF ; clr 优先, 其余保持
// ★题二接法: set = "下一状态是 FS_ERR 或 DRIVER_ERR"
//            clr = "下一状态是 INIT" ; 全局 rst 也清
// ---------------------------------------------------------------------
module buzzer_alarm (
    input  wire clk,
    input  wire rst,
    input  wire set,        // 报错事件 (电平或脉冲均可, 置上就不放)
    input  wire clr,        // 解除事件
    output reg  buzz
);
    always @(posedge clk or posedge rst) begin
        if (rst)      buzz <= 1'b0;
        else if (clr) buzz <= 1'b0;
        else if (set) buzz <= 1'b1;
    end
endmodule

// ---------------------------------------------------------------------
// 打法2 buzzer_beep: 触发后响 N 拍自动停, 停的那拍给出 done 脉冲
// ★参数表: N = 响的拍数 (题三 N=2)
// ★时序: trig 被采样的边沿起 buzz=1, 满 N 拍的边沿 buzz=0 且 done=1
//         (done 只持续 1 拍, 专门用来触发"响完之后的那件事":
//          题三的打印学号、流水跑完收尾、计数清零都接它)
//   busy 期间的新 trig 忽略 (★约定: 要排队响两次用打法3, 不用这个)
// ---------------------------------------------------------------------
module buzzer_beep #(
    parameter N = 2
)(
    input  wire clk,
    input  wire rst,
    input  wire trig,
    output reg  buzz,
    output reg  busy,
    output reg  done        // 结束脉冲, 1 拍
);
    reg [31:0] cnt;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            buzz <= 1'b0; busy <= 1'b0; done <= 1'b0; cnt <= 32'd0;
        end else begin
            done <= 1'b0;                       // done 默认 0, 只在结束拍拉高
            if (!busy) begin
                if (trig) begin busy <= 1'b1; buzz <= 1'b1; cnt <= 32'd0; end
            end else if (cnt == N-1) begin
                busy <= 1'b0; buzz <= 1'b0; done <= 1'b1; cnt <= 32'd0;
            end else begin
                cnt <= cnt + 1'b1;
            end
        end
    end
endmodule

// ---------------------------------------------------------------------
// 打法3 buzzer_beeps: 响 TIMES 声, 每声 ON_LEN 拍, 间隔 OFF_LEN 拍
// ★参数表: ON_LEN 每声拍数, OFF_LEN 间隔拍数, TIMES 声数
// ★状态表 (它本身就是个三状态的小三段式, 照模板套路读):
//   B_IDLE --trig--> B_ON
//   B_ON   --本声响满--> 最后一声 ? B_IDLE(出 done) : B_OFF
//   B_OFF  --间隔满--> B_ON (声计数 +1 在 B_ON 结束时发生)
// 例: 开机"滴-滴-滴" = ON_LEN=2, OFF_LEN=2, TIMES=3
// ---------------------------------------------------------------------
module buzzer_beeps #(
    parameter ON_LEN  = 2,
    parameter OFF_LEN = 2,
    parameter TIMES   = 3
)(
    input  wire clk,
    input  wire rst,
    input  wire trig,
    output wire buzz,
    output reg  done
);
    localparam [1:0] B_IDLE = 2'd0, B_ON = 2'd1, B_OFF = 2'd2;
    reg [1:0]  cur, nxt;
    reg [31:0] phase_cnt;   // 当前声/间隔已走拍数
    reg [31:0] beep_cnt;    // 已响完的声数 (在 B_ON 结束拍 +1)

    wire [31:0] phase_lim  = (cur == B_ON) ? ON_LEN : OFF_LEN;
    wire        phase_done = (cur != B_IDLE) && (phase_cnt == phase_lim - 1);
    wire        last_beep  = (beep_cnt == TIMES - 1);

    // 第一段: 状态登记
    always @(posedge clk or posedge rst) begin
        if (rst) cur <= B_IDLE;
        else     cur <= nxt;
    end
    // 第二段: 下一状态
    always @(*) begin
        nxt = cur;
        case (cur)
            B_IDLE: if (trig)       nxt = B_ON;
            B_ON:   if (phase_done) nxt = last_beep ? B_IDLE : B_OFF;
            B_OFF:  if (phase_done) nxt = B_ON;
            default: nxt = B_IDLE;
        endcase
    end
    // 第三段: 输出 (Moore: 在 B_ON 就响)
    assign buzz = (cur == B_ON);
    // 计数器组: 相位计数状态内自增, 满清零; 声计数只在 B_ON 结束拍 +1
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            phase_cnt <= 32'd0; beep_cnt <= 32'd0; done <= 1'b0;
        end else begin
            done <= (cur == B_ON) && phase_done && last_beep;
            if (cur == B_IDLE) begin
                phase_cnt <= 32'd0; beep_cnt <= 32'd0;
            end else if (phase_done) begin
                phase_cnt <= 32'd0;
                if (cur == B_ON) beep_cnt <= beep_cnt + 1'b1;
            end else begin
                phase_cnt <= phase_cnt + 1'b1;
            end
        end
    end
endmodule

// ---------------------------------------------------------------------
// 打法4 buzzer_tone: 无源蜂鸣器音调方波 (只上板用, 仿真题不要加)
// ★参数表: HALF = CLK_FREQ / (2 x FREQ)
//   例: 100MHz, 要 2kHz -> HALF = 100_000_000 / 4000 = 25000
//   常用音调: 1kHz 听感低沉, 2~4kHz 最刺耳最常用
// 原理: 无源蜂鸣器没有自带振荡, 必须喂方波才响, 频率即音调;
//       en=1 才输出方波, en=0 输出 0 (静音且相位归零, 再开从头起振)
// ---------------------------------------------------------------------
module buzzer_tone #(
    parameter CLK_FREQ = 100_000_000,
    parameter FREQ     = 2000
)(
    input  wire clk,
    input  wire rst,
    input  wire en,         // 接前三种打法的响电平
    output reg  wave        // 接蜂鸣器引脚
);
    localparam integer HALF = CLK_FREQ / (2 * FREQ);
    reg [31:0] cnt;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            cnt <= 32'd0; wave <= 1'b0;
        end else if (!en) begin
            cnt <= 32'd0; wave <= 1'b0;
        end else if (cnt == HALF-1) begin
            cnt <= 32'd0; wave <= ~wave;
        end else begin
            cnt <= cnt + 1'b1;
        end
    end
endmodule

// =====================================================================
// 组合图 (上板无源版): 前三种给"响不响", 打法4 给"怎么响"
//   level = alarm.q / beep.buzz / beeps.buzz   (三选一)
//   buzzer_tone #(.FREQ(2000)) u_tone (.en(level), .wave(pin_buzzer));
// 仿真题: pin_buzzer = level, 到此为止, 不例化 tone。
// =====================================================================
