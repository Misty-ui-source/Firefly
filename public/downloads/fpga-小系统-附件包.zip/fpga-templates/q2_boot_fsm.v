// =====================================================================
// 题二 操作系统启动自检报错状态机
// 本文件自包含, 端口按题面"输入输出端口说明"命名
//
// ★★★ 参数表 ★★★
//  ID_LAST2 = 8'd0 : ★占位, 必须改成自己学号的后两位 (十进制直接写,
//                    例: 后两位 07 就写 8'd7, o_msg 按十进制数值输出)
//  i_rstn 低电平有效 (题面给定); i_rst_btn 高电平表示按下 (题面给定),
//      跳转判据按"电平"写: 按下期间条件成立, 不是边沿
//
// ★★★ 状态表 (编码按流程顺序排, 读波形时状态值就是进度) ★★★
//  状态       编码  跳转条件 -> 下一状态
//  INIT       000   无条件 -> CHECK_FS
//  CHECK_FS   001   i_fs_err=1 -> FS_ERR ; =0 -> FS_OK
//  FS_OK      010   无条件 -> LD_DRIVER
//  FS_ERR     011   i_rst_btn=1 -> INIT ; 否则保持
//  LD_DRIVER  100   i_driver_err=1 -> DRIVER_ERR ; =0 -> DRIVER_OK
//  DRIVER_OK  101   无条件 -> BOOT_OK
//  DRIVER_ERR 110   i_rst_btn=1 -> INIT ; 否则保持
//  BOOT_OK    111   i_rst_btn=1 -> INIT ; 否则保持
//  (题面左栏 FS_OKK 是笔误, 即 FS_OK)
//
// ★★★ 输出表 (这道题输出不是纯 Moore, 是"置位-清除锁存") ★★★
//  o_led[0] : 进入 FS_OK 时置 1, 一直保持, 进入 INIT 才清 0
//  o_led[1] : 进入 DRIVER_OK 时置 1, 一直保持, 进入 INIT 才清 0
//  o_buzzer : 进入任一 ERR 状态时置 1, 一直保持, 进入 INIT 才清 0
//  o_msg    : 进入 BOOT_OK 时赋 ID_LAST2, 进入 INIT 清 0
//  ★实现要点: 锁存的置位/清除看 nxt (下一状态) 而不是 cur,
//    这样在进入该状态的当拍输出就已经对齐, 不会慢一拍
// =====================================================================
module boot_fsm #(
    parameter [7:0] ID_LAST2 = 8'd0     // ★改: 自己学号后两位
)(
    input  wire       i_clk,
    input  wire       i_rstn,           // 低电平有效
    input  wire       i_fs_err,         // 高 = 文件系统错误
    input  wire       i_driver_err,     // 高 = 驱动错误
    input  wire       i_rst_btn,        // 高 = 按下
    output reg  [1:0] o_led,            // [0]=FS 成功灯, [1]=DRIVER 成功灯
    output reg  [7:0] o_msg,            // BOOT_OK 后输出学号后两位
    output reg        o_buzzer          // 高 = 蜂鸣器工作
);
    // ---------- ★ 状态编码区 ----------
    localparam [2:0] INIT       = 3'd0,
                     CHECK_FS   = 3'd1,
                     FS_OK      = 3'd2,
                     FS_ERR     = 3'd3,
                     LD_DRIVER  = 3'd4,
                     DRIVER_OK  = 3'd5,
                     DRIVER_ERR = 3'd6,
                     BOOT_OK    = 3'd7;

    reg [2:0] cur, nxt;

    // ---------- 三段式 第一段: 状态登记 ----------
    always @(posedge i_clk or negedge i_rstn) begin
        if (!i_rstn) cur <= INIT;
        else         cur <= nxt;
    end

    // ---------- 三段式 第二段: 下一状态 (照状态表逐行填) ----------
    always @(*) begin
        nxt = cur;
        case (cur)
            INIT:       nxt = CHECK_FS;
            CHECK_FS:   nxt = i_fs_err     ? FS_ERR : FS_OK;
            FS_OK:      nxt = LD_DRIVER;
            FS_ERR:     nxt = i_rst_btn    ? INIT   : FS_ERR;
            LD_DRIVER:  nxt = i_driver_err ? DRIVER_ERR : DRIVER_OK;
            DRIVER_OK:  nxt = BOOT_OK;
            DRIVER_ERR: nxt = i_rst_btn    ? INIT   : DRIVER_ERR;
            BOOT_OK:    nxt = i_rst_btn    ? INIT   : BOOT_OK;
            default:    nxt = INIT;
        endcase
    end

    // ---------- 三段式 第三段: 输出锁存 (置位/清除看 nxt, 见输出表) ----------
    always @(posedge i_clk or negedge i_rstn) begin
        if (!i_rstn) begin
            o_led <= 2'b00; o_msg <= 8'd0; o_buzzer <= 1'b0;
        end else if (nxt == INIT) begin
            o_led <= 2'b00; o_msg <= 8'd0; o_buzzer <= 1'b0;   // clr 优先
        end else begin
            if (nxt == FS_OK)     o_led[0] <= 1'b1;            // set 后自动保持
            if (nxt == DRIVER_OK) o_led[1] <= 1'b1;
            if (nxt == FS_ERR || nxt == DRIVER_ERR) o_buzzer <= 1'b1;
            if (nxt == BOOT_OK)   o_msg <= ID_LAST2;
        end
    end
endmodule
