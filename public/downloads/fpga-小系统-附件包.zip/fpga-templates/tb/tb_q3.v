// 题三自测 TB: iverilog -o tb_q3 tb_q3.v ../q3_rice_cooker.v
`timescale 1ns/1ps
module tb_q3;
    reg clk=0, rstn=0, set=0, mode=0, extra=0; reg [7:0] tme=0;
    wire [3:0] led; wire buzzer; wire [20:0] prt;
    integer err=0;
    rice_cooker #(.STUDENT_ID(21'd1234567)) dut(.i_clk(clk), .i_rstn(rstn), .i_set(set),
        .i_mode(mode), .i_time(tme), .i_extra(extra), .o_led(led), .o_buzzer(buzzer), .o_print(prt));
    always #5 clk = ~clk;
    task step; input integer n; integer k;
        begin for (k=0;k<n;k=k+1) @(negedge clk); end
    endtask
    task chkstate; input [1:0] exp; input [127:0] name;
        begin if (dut.cur !== exp) begin err=err+1; $display("FAIL %0s: state=%0d exp=%0d led=%b", name, dut.cur, exp, led); end
              else $display("OK   %0s: state=%0d led=%b buzz=%b print=%0d", name, dut.cur, led, buzzer, prt); end
    endtask

    initial begin
        step(2); rstn=1; step(1);
        chkstate(2'd0, "IDLE");
        // 做饭 (extra=0, 每2拍一格): 进RICE后 2/4/6/8 拍填格, 第8拍进保温
        set=1; mode=0; extra=0; step(1); chkstate(2'd1, "RICE start");
        step(2); if (led!==4'b1000) begin err=err+1; $display("FAIL rice prog1 led=%b", led); end
        step(2); if (led!==4'b1100) begin err=err+1; $display("FAIL rice prog2 led=%b", led); end
        step(4); chkstate(2'd3, "INSUL after 8cyc rice");
        if (led!==4'b1111) begin err=err+1; $display("FAIL insul led=%b", led); end
        // 关机: 蜂鸣2拍, 之后打印
        set=0; step(1); chkstate(2'd0, "back IDLE");
        if (buzzer!==1'b1) begin err=err+1; $display("FAIL buzzer not on at exit"); end
        step(2);
        if (buzzer!==1'b0) begin err=err+1; $display("FAIL buzzer not off after 2cyc"); end
        if (prt!==21'd1234567) begin err=err+1; $display("FAIL print=%0d", prt); end
        else $display("OK   buzzer 2cyc then print id");
        // 煮粥 (time=5): PORRIDGE 停留5拍进保温
        set=1; mode=1; tme=8'd5; step(1); chkstate(2'd2, "PORRIDGE start");
        if (prt!==21'd0) begin err=err+1; $display("FAIL print not cleared on start"); end
        step(5); chkstate(2'd3, "INSUL after 5cyc porridge");
        set=0; step(3);
        // 锅巴做饭 (extra=1, 每4拍一格): 16拍进保温
        set=1; mode=0; extra=1; step(1); chkstate(2'd1, "RICE extra start");
        step(4); if (led!==4'b1000) begin err=err+1; $display("FAIL extra prog1 led=%b", led); end
        step(12); chkstate(2'd3, "INSUL after 16cyc extra rice");
        set=0; step(1);
        if (err==0) $display("TB_Q3 ALL PASS");
        else        $display("TB_Q3 FAILED err=%0d", err);
        $finish;
    end
endmodule
