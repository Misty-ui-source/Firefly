// 题二自测 TB: iverilog -o tb_q2 tb_q2.v ../q2_boot_fsm.v
`timescale 1ns/1ps
module tb_q2;
    reg clk=0, rstn=0, fs_err=0, drv_err=0, rst_btn=0;
    wire [1:0] led; wire [7:0] msg; wire buzzer;
    integer err=0;
    boot_fsm #(.ID_LAST2(8'd42)) dut(.i_clk(clk), .i_rstn(rstn), .i_fs_err(fs_err),
        .i_driver_err(drv_err), .i_rst_btn(rst_btn), .o_led(led), .o_msg(msg), .o_buzzer(buzzer));
    always #5 clk = ~clk;
    task step; input integer n; integer k;
        begin for (k=0;k<n;k=k+1) @(negedge clk); end
    endtask
    task chkstate; input [2:0] exp; input [127:0] name;
        begin if (dut.cur !== exp) begin err=err+1; $display("FAIL %0s: state=%0d exp=%0d", name, dut.cur, exp); end
              else $display("OK   %0s: state=%0d led=%b msg=%0d buzz=%b", name, dut.cur, led, msg, buzzer); end
    endtask

    initial begin
        step(2); rstn=1;
        // 正常路径: INIT->CHECK_FS->FS_OK->LD_DRIVER->DRIVER_OK->BOOT_OK
        step(1); chkstate(3'd1, "CHECK_FS");
        step(1); chkstate(3'd2, "FS_OK");
        if (led[0] !== 1'b1) begin err=err+1; $display("FAIL led0 not on in FS_OK"); end
        step(1); chkstate(3'd4, "LD_DRIVER");
        step(1); chkstate(3'd5, "DRIVER_OK");
        if (led !== 2'b11) begin err=err+1; $display("FAIL leds not both on led=%b", led); end
        step(1); chkstate(3'd7, "BOOT_OK");
        if (msg !== 8'd42) begin err=err+1; $display("FAIL msg=%0d exp=42", msg); end
        step(2); chkstate(3'd7, "BOOT_OK holds");
        rst_btn=1; step(1); rst_btn=0;
        if (led!==2'b00 || msg!==8'd0 || buzzer!==1'b0) begin err=err+1; $display("FAIL outputs not cleared at INIT"); end
        else $display("OK   outputs cleared at INIT");
        // FS 错误路径
        fs_err=1;
        step(2); chkstate(3'd3, "FS_ERR");
        if (buzzer !== 1'b1) begin err=err+1; $display("FAIL buzzer off in FS_ERR"); end
        step(2); chkstate(3'd3, "FS_ERR holds w/o btn");
        rst_btn=1; step(1); rst_btn=0; fs_err=0;
        chkstate(3'd0, "FS_ERR btn -> INIT (or just left)");
        // Driver 错误路径
        step(3); // INIT->CHECK->FS_OK->LD_DRIVER
        drv_err=1; step(1);
        chkstate(3'd6, "DRIVER_ERR");
        if (buzzer !== 1'b1 || led[0] !== 1'b1) begin err=err+1; $display("FAIL drv err: buzz=%b led=%b", buzzer, led); end
        rst_btn=1; step(1); rst_btn=0; drv_err=0;
        if (err==0) $display("TB_Q2 ALL PASS");
        else        $display("TB_Q2 FAILED err=%0d", err);
        $finish;
    end
endmodule
