// 蜂鸣器专题自测 TB: iverilog -o tb_buzz tb_buzzer.v ../buzzer_special.v
`timescale 1ns/1ps
module tb_buzzer;
    reg clk=0, rst=1;
    integer err=0;
    always #5 clk = ~clk;
    task step; input integer n; integer k;
        begin for (k=0;k<n;k=k+1) @(negedge clk); end
    endtask

    // ---- alarm ----
    reg a_set=0, a_clr=0; wire a_buzz;
    buzzer_alarm u_alarm(.clk(clk), .rst(rst), .set(a_set), .clr(a_clr), .buzz(a_buzz));
    // ---- beep N=3 ----
    reg b_trig=0; wire b_buzz, b_busy, b_done;
    buzzer_beep #(.N(3)) u_beep(.clk(clk), .rst(rst), .trig(b_trig),
                                .buzz(b_buzz), .busy(b_busy), .done(b_done));
    // ---- beeps 2/2 x3 ----
    reg s_trig=0; wire s_buzz, s_done;
    buzzer_beeps #(.ON_LEN(2), .OFF_LEN(2), .TIMES(3)) u_beeps(.clk(clk), .rst(rst),
                                .trig(s_trig), .buzz(s_buzz), .done(s_done));
    // ---- tone HALF=5 ----
    reg t_en=0; wire t_wave;
    buzzer_tone #(.CLK_FREQ(1000), .FREQ(100)) u_tone(.clk(clk), .rst(rst),
                                .en(t_en), .wave(t_wave));

    integer cnt, i;
    reg [9:0] pat;
    initial begin
        step(2); rst=0; step(1);

        // alarm: set 后保持, clr 后灭
        a_set=1; step(1); a_set=0; step(2);
        if (a_buzz!==1'b1) begin err=err+1; $display("FAIL alarm not latched"); end
        else $display("OK   alarm latched on");
        a_clr=1; step(1); a_clr=0;
        if (a_buzz!==1'b0) begin err=err+1; $display("FAIL alarm not cleared"); end
        else $display("OK   alarm cleared");

        // beep: trig 后恰好响 3 拍, 结束拍 done=1
        b_trig=1; step(1); b_trig=0;
        cnt=0;
        for (i=0;i<10;i=i+1) begin
            if (b_buzz===1'b1) cnt=cnt+1;
            step(1);
        end
        if (cnt!==3) begin err=err+1; $display("FAIL beep len=%0d exp=3", cnt); end
        else $display("OK   beep length 3 cycles");
        // 再测一次 done: 重新触发, 等 buzz 落下那拍查 done
        b_trig=1; step(1); b_trig=0;
        while (b_buzz===1'b1) step(1);
        if (b_done!==1'b1) begin err=err+1; $display("FAIL beep done missing"); end
        else $display("OK   beep done pulse at end");
        step(1);
        if (b_done!==1'b0) begin err=err+1; $display("FAIL beep done too long"); end

        // beeps: 图案应为 1100110011, 之后 done
        s_trig=1; step(1); s_trig=0;
        for (i=0;i<10;i=i+1) begin pat[9-i]=s_buzz; step(1); end
        if (pat!==10'b1100110011) begin err=err+1; $display("FAIL beeps pat=%b", pat); end
        else $display("OK   beeps pattern 1100110011");
        if (s_done!==1'b1) begin err=err+1; $display("FAIL beeps done missing"); end
        else $display("OK   beeps done");

        // tone: en 后应有翻转, en=0 后归 0
        t_en=1; step(1);
        cnt=0; for (i=0;i<20;i=i+1) begin if (t_wave===1'b1) cnt=cnt+1; step(1); end
        if (cnt<5 || cnt>15) begin err=err+1; $display("FAIL tone duty cnt=%0d/20", cnt); end
        else $display("OK   tone toggling, high %0d/20 cycles", cnt);
        t_en=0; step(2);
        if (t_wave!==1'b0) begin err=err+1; $display("FAIL tone not silent when en=0"); end
        else $display("OK   tone silent when en=0");

        if (err==0) $display("TB_BUZZER ALL PASS");
        else        $display("TB_BUZZER FAILED err=%0d", err);
        $finish;
    end
endmodule
