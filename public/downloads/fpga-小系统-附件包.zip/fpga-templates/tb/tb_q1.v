// 题一自测 TB (非官方, 只验本文件逻辑): iverilog -o tb_q1 tb_q1.v ../q1_led_control.v
`timescale 1ns/1ps
module tb_q1;
    reg clk=0, rst=1; reg [1:0] btn=0; wire [3:0] led;
    integer err=0;
    led_control dut(.clk(clk), .rst(rst), .btn(btn), .led(led));
    always #5 clk = ~clk;

    task step; input integer n; integer k;
        begin for (k=0;k<n;k=k+1) @(negedge clk); end
    endtask
    task pulse; input [1:0] b;
        begin @(negedge clk); btn=b; @(negedge clk); btn=2'b00; end
    endtask
    task check; input [3:0] exp; input [127:0] name;
        begin if (led !== exp) begin err=err+1; $display("FAIL %0s: led=%b exp=%b t=%0t", name, led, exp, $time); end
              else $display("OK   %0s: led=%b", name, led); end
    endtask

    initial begin
        step(2); rst=0; step(1);
        check(4'b0000, "init mode1 off");
        pulse(2'b10); check(4'b1111, "btn1 -> mode2 on");
        pulse(2'b10); check(4'b1111, "btn1 -> mode3 blink start lit");
        step(10);     check(4'b0000, "blink after 10cyc off");
        step(10);     check(4'b1111, "blink after 20cyc on");
        pulse(2'b10); // -> FLOW, pattern restarts
        if (led !== 4'b0001 && led !== 4'b0010) begin err=err+1; $display("FAIL flow start led=%b", led); end
        else $display("OK   flow start led=%b", led);
        pulse(2'b10); check(4'b0000, "btn1 wrap flow->off");
        pulse(2'b01); // prev from OFF wraps to FLOW
        if (led === 4'b0000 || led === 4'b1111) begin err=err+1; $display("FAIL btn0 wrap to flow led=%b", led); end
        else $display("OK   btn0 wrap to flow led=%b", led);
        pulse(2'b01); check(4'b1111, "btn0 flow->blink? (blink restarts lit)");
        if (err==0) $display("TB_Q1 ALL PASS");
        else        $display("TB_Q1 FAILED err=%0d", err);
        $finish;
    end
endmodule
