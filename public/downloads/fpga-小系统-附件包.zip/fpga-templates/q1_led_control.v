// =====================================================================
// 题一 (2023秋真题) 节日彩灯控制 led_control
// 2 个按键 btn[1:0], 4 个 LED, 4 种模式循环切换
// 本文件自包含, 可直接配官方 TB led_control_tb.v 仿真
//
// ★★★ 参数表 (先定参数, 再看代码) ★★★
//  CLK = 100MHz -> T = 10ns                     (题目给定)
//  BLINK_HALF_CYC = 10 : 闪烁周期 200ns, 亮半个周期 100ns = 10 拍翻转一次
//      -> 若 TB 约定"亮 200ns 再灭 200ns", 只改这一个数: 10 -> 20
//  FLOW_STEP_CYC  = 1  : 题目"每个周期进行流水" -> 每 1 拍移一位
//  rst 按高电平有效写 (题面只写 rst 未注极性); 若 TB 是低有效,
//      把所有 rst 判断取反即可, 状态表不用动
//
// ★★★ 状态表 (= 模式表, 状态编码故意取模式序号-1, 查表不用翻译) ★★★
//  状态       编码   led 输出            怎么离开
//  M_OFF      00     0000               btn 沿事件改模式 (见下)
//  M_ON       01     1111               同上
//  M_BLINK    10     blink_pat 翻转     同上
//  M_FLOW     11     flow_pat 移位      同上
//  跳转规则 (四个状态完全相同, 所以第二段只有两行有效逻辑):
//      btn[1] 上升沿 -> 下一模式 (M_FLOW 之后回绕到 M_OFF)
//      btn[0] 上升沿 -> 上一模式 (M_OFF 之后回绕到 M_FLOW)
//      两键同沿 -> btn[1] 优先 (★约定, 题面未规定, 按需可改)
//      无沿       -> 保持当前模式
// =====================================================================
module led_control (
    input  wire       clk,
    input  wire       rst,          // 高电平有效 (见参数表说明)
    input  wire [1:0] btn,
    output reg  [3:0] led
);
    // ---------- ★ 参数区 ----------
    parameter BLINK_HALF_CYC = 10;  // 闪烁半周期拍数, 推导见文件头
    parameter FLOW_STEP_CYC  = 1;   // 流水每几拍移一位

    // ---------- ★ 状态编码区 ----------
    localparam [1:0] M_OFF   = 2'd0,
                     M_ON    = 2'd1,
                     M_BLINK = 2'd2,
                     M_FLOW  = 2'd3;

    reg [1:0] cur, nxt;

    // ---------- 小模块1: 按键边沿检测 (逐位) ----------
    reg  [1:0] btn_d;
    wire [1:0] btn_pos;
    always @(posedge clk or posedge rst) begin
        if (rst) btn_d <= 2'b00;
        else     btn_d <= btn;
    end
    assign btn_pos = btn & ~btn_d;      // [1]=下一模式, [0]=上一模式

    // ---------- 三段式 第一段: 状态登记 ----------
    always @(posedge clk or posedge rst) begin
        if (rst) cur <= M_OFF;          // 初始模式1
        else     cur <= nxt;
    end

    // ---------- 三段式 第二段: 下一状态 (照状态表填) ----------
    always @(*) begin
        nxt = cur;
        if (btn_pos[1])
            nxt = (cur == M_FLOW) ? M_OFF : cur + 2'd1;
        else if (btn_pos[0])
            nxt = (cur == M_OFF)  ? M_FLOW : cur - 2'd1;
    end

    // ---------- 数据通路A: 闪烁图案 (只在 M_BLINK 推进, 退出归位) ----------
    reg [31:0] blink_cnt;
    reg [3:0]  blink_pat;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            blink_cnt <= 32'd0; blink_pat <= 4'b1111;
        end else if (cur != M_BLINK) begin
            blink_cnt <= 32'd0; blink_pat <= 4'b1111;  // 进模式时从"全亮"起
        end else if (blink_cnt == BLINK_HALF_CYC-1) begin
            blink_cnt <= 32'd0; blink_pat <= ~blink_pat;
        end else begin
            blink_cnt <= blink_cnt + 1'b1;
        end
    end

    // ---------- 数据通路B: 流水图案 (只在 M_FLOW 推进, 退出归位) ----------
    reg [31:0] flow_cnt;
    reg [3:0]  flow_pat;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            flow_cnt <= 32'd0; flow_pat <= 4'b0001;
        end else if (cur != M_FLOW) begin
            flow_cnt <= 32'd0; flow_pat <= 4'b0001;    // 起始位 LD0 侧
        end else if (flow_cnt == FLOW_STEP_CYC-1) begin
            flow_cnt <= 32'd0;
            flow_pat <= {flow_pat[2:0], flow_pat[3]}; // 0001->0010->0100->1000->回绕
            // ★方向约定: 题面未规定流水方向, 若 TB 按高位起跑,
            //   起始改 4'b1000 且移位改 {flow_pat[0], flow_pat[3:1]}
        end else begin
            flow_cnt <= flow_cnt + 1'b1;
        end
    end

    // ---------- 三段式 第三段: 输出选择 (图案已由数据通路算好, 这里只选) ----------
    always @(*) begin
        case (cur)
            M_OFF:   led = 4'b0000;
            M_ON:    led = 4'b1111;
            M_BLINK: led = blink_pat;
            M_FLOW:  led = flow_pat;
            default: led = 4'b0000;
        endcase
    end
endmodule
