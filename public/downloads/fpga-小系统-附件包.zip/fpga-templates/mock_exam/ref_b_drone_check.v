// =====================================================================
// 模拟题二 参考实现: 无人机起飞前自检 (先自己做, 卡住再看)
// 结构与题二启动自检完全同构: 顺序两段检查 + 错误保持 + 输出锁存。
// ★★★ 参数表 ★★★
//  ID_LAST2 ★改自己的学号后两位 (十进制); i_rst_btn 按电平判断
// ★★★ 状态表 (编码按流程顺序) ★★★
//  INIT    000  无条件 -> CHK_BAT
//  CHK_BAT 001  i_bat_low=1 -> BAT_ERR ; =0 -> BAT_OK
//  BAT_OK  010  无条件 -> CHK_MOT
//  BAT_ERR 011  i_rst_btn=1 -> INIT ; 否则保持
//  CHK_MOT 100  i_mot_err=1 -> MOT_ERR ; =0 -> MOT_OK
//  MOT_OK  101  无条件 -> READY
//  MOT_ERR 110  i_rst_btn=1 -> INIT ; 否则保持
//  READY   111  i_rst_btn=1 -> INIT ; 否则保持
// ★★★ 输出表 (置位-清除锁存, 置位/清除看 nxt, 进入当拍对齐) ★★★
//  o_led[0] 进 BAT_OK 置 1, 进 INIT 清; o_led[1] 进 MOT_OK 置 1, 进 INIT 清
//  o_buzzer 进任一 ERR 置 1, 进 INIT 清; o_msg 进 READY 赋 ID_LAST2, 进 INIT 清
// =====================================================================
module drone_check #(
    parameter [7:0] ID_LAST2 = 8'd0       // ★改: 自己的学号后两位
)(
    input  wire       i_clk,
    input  wire       i_rstn,
    input  wire       i_bat_low,
    input  wire       i_mot_err,
    input  wire       i_rst_btn,
    output reg  [1:0] o_led,
    output reg  [7:0] o_msg,
    output reg        o_buzzer
);
    localparam [2:0] INIT    = 3'd0, CHK_BAT = 3'd1, BAT_OK  = 3'd2,
                     BAT_ERR = 3'd3, CHK_MOT = 3'd4, MOT_OK  = 3'd5,
                     MOT_ERR = 3'd6, READY   = 3'd7;
    reg [2:0] cur, nxt;

    always @(posedge i_clk or negedge i_rstn) begin
        if (!i_rstn) cur <= INIT;
        else         cur <= nxt;
    end
    always @(*) begin
        nxt = cur;
        case (cur)
            INIT:    nxt = CHK_BAT;
            CHK_BAT: nxt = i_bat_low ? BAT_ERR : BAT_OK;
            BAT_OK:  nxt = CHK_MOT;
            BAT_ERR: nxt = i_rst_btn ? INIT : BAT_ERR;
            CHK_MOT: nxt = i_mot_err ? MOT_ERR : MOT_OK;
            MOT_OK:  nxt = READY;
            MOT_ERR: nxt = i_rst_btn ? INIT : MOT_ERR;
            READY:   nxt = i_rst_btn ? INIT : READY;
            default: nxt = INIT;
        endcase
    end
    always @(posedge i_clk or negedge i_rstn) begin
        if (!i_rstn) begin
            o_led <= 2'b00; o_msg <= 8'd0; o_buzzer <= 1'b0;
        end else if (nxt == INIT) begin
            o_led <= 2'b00; o_msg <= 8'd0; o_buzzer <= 1'b0;
        end else begin
            if (nxt == BAT_OK)  o_led[0] <= 1'b1;
            if (nxt == MOT_OK)  o_led[1] <= 1'b1;
            if (nxt == BAT_ERR || nxt == MOT_ERR) o_buzzer <= 1'b1;
            if (nxt == READY)   o_msg <= ID_LAST2;
        end
    end
endmodule
