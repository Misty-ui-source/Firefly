// 模拟题一自测 TB: iverilog -o tb_a tb_a_washer.v ../ref_a_washer.v
`timescale 1ns/1ps
module tb_a_washer;
    reg clk=0, rstn=0, start=0, gentle=0; reg [7:0] tme=0;
    wire [3:0] led; wire buzzer; wire [20:0] prt;
    integer err=0, n;
    washer_ctrl #(.STUDENT_ID(21'd1234567)) dut(.i_clk(clk), .i_rstn(rstn),
        .i_start(start), .i_time(tme), .i_gentle(gentle), .o_led(led),
        .o_buzzer(buzzer), .o_print(prt));
    always #5 clk = ~clk;
    task step; input integer k; integer j;
        begin for (j=0;j<k;j=j+1) @(negedge clk); end
    endtask
    // 数当前状态停留拍数 (调用时须刚进入该状态), 返回后已进入下一状态
    task count_state; input [2:0] s; output integer cnt;
        begin cnt=0; while (dut.cur===s && cnt<1000) begin cnt=cnt+1; step(1); end end
    endtask
    task expect_dur; input [2:0] s; input integer exp; input [127:0] name;
        begin count_state(s, n);
              if (n!==exp) begin err=err+1; $display("FAIL %0s dur=%0d exp=%0d", name, n, exp); end
              else $display("OK   %0s dur=%0d", name, n); end
    endtask

    initial begin
        step(2); rstn=1; step(1);
        if (dut.cur!==3'd0) begin err=err+1; $display("FAIL not IDLE after rst"); end
        // 常规洗: time=6
        tme=8'd6; gentle=0; start=1; step(1);
        expect_dur(3'd1, 3, "FILL");
        if (led!==4'b1000) begin err=err+1; $display("FAIL wash flow start led=%b", led); end
        expect_dur(3'd2, 6, "WASH t=6");
        expect_dur(3'd3, 4, "RINSE");
        // SPIN: 手工采前两拍图案 + 数时长
        if (led!==4'b1111) begin err=err+1; $display("FAIL spin first led=%b", led); end
        step(1); if (led!==4'b0000) begin err=err+1; $display("FAIL spin second led=%b", led); end
        n=2; while (dut.cur===3'd4 && n<100) begin step(1); if (dut.cur===3'd4) n=n+1; end
        if (n!==5) begin err=err+1; $display("FAIL SPIN dur=%0d exp=5", n); end
        else $display("OK   SPIN dur=5, blink starts 1111");
        if (dut.cur!==3'd5 || led!==4'b1111) begin err=err+1; $display("FAIL DONE state/led"); end
        else $display("OK   DONE led=1111");
        // 关机: 蜂鸣3拍后打印
        start=0; step(1);
        if (buzzer!==1'b1) begin err=err+1; $display("FAIL buzzer off at exit"); end
        step(3);
        if (buzzer!==1'b0) begin err=err+1; $display("FAIL buzzer not off after 3"); end
        if (prt!==21'd1234567) begin err=err+1; $display("FAIL print=%0d", prt); end
        else $display("OK   beep 3 cycles then print");
        // 轻柔洗: time=3 -> WASH 应为 6 拍
        tme=8'd3; gentle=1; start=1; step(1);
        expect_dur(3'd1, 3, "FILL#2");
        expect_dur(3'd2, 6, "WASH gentle t=3 x2");
        start=0; // DONE 前改 start 不影响流程, 只在 DONE 判断
        count_state(3'd3, n); count_state(3'd4, n);
        step(1); // DONE 停留一拍后因 start=0 退出
        if (dut.cur!==3'd0 && dut.cur!==3'd5) begin err=err+1; $display("FAIL end state=%0d", dut.cur); end
        if (err==0) $display("TB_A ALL PASS");
        else        $display("TB_A FAILED err=%0d", err);
        $finish;
    end
endmodule
