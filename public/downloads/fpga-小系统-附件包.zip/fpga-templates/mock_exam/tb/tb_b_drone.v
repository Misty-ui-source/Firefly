// 模拟题二自测 TB: iverilog -o tb_b tb_b_drone.v ../ref_b_drone_check.v
`timescale 1ns/1ps
module tb_b_drone;
    reg clk=0, rstn=0, bat_low=0, mot_err=0, rst_btn=0;
    wire [1:0] led; wire [7:0] msg; wire buzzer;
    integer err=0;
    drone_check #(.ID_LAST2(8'd37)) dut(.i_clk(clk), .i_rstn(rstn), .i_bat_low(bat_low),
        .i_mot_err(mot_err), .i_rst_btn(rst_btn), .o_led(led), .o_msg(msg), .o_buzzer(buzzer));
    always #5 clk = ~clk;
    task step; input integer k; integer j;
        begin for (j=0;j<k;j=j+1) @(negedge clk); end
    endtask
    task chkstate; input [2:0] exp; input [127:0] name;
        begin if (dut.cur!==exp) begin err=err+1; $display("FAIL %0s state=%0d exp=%0d", name, dut.cur, exp); end
              else $display("OK   %0s state=%0d led=%b msg=%0d buzz=%b", name, dut.cur, led, msg, buzzer); end
    endtask

    initial begin
        step(2); rstn=1;
        step(1); chkstate(3'd1, "CHK_BAT");
        step(1); chkstate(3'd2, "BAT_OK");
        if (led[0]!==1'b1) begin err=err+1; $display("FAIL led0 not on in BAT_OK"); end
        step(1); chkstate(3'd4, "CHK_MOT");
        step(1); chkstate(3'd5, "MOT_OK");
        step(1); chkstate(3'd7, "READY");
        if (led!==2'b11 || msg!==8'd37) begin err=err+1; $display("FAIL ready led=%b msg=%0d", led, msg); end
        rst_btn=1; step(1); rst_btn=0;
        if (led!==2'b00 || msg!==8'd0) begin err=err+1; $display("FAIL not cleared at INIT"); end
        else $display("OK   cleared at INIT");
        // 电池错误
        bat_low=1; step(2); chkstate(3'd3, "BAT_ERR");
        if (buzzer!==1'b1) begin err=err+1; $display("FAIL buzzer off in BAT_ERR"); end
        step(2); chkstate(3'd3, "BAT_ERR holds");
        rst_btn=1; step(1); rst_btn=0; bat_low=0;
        // 电机错误 (电池先过)
        step(3); chkstate(3'd4, "CHK_MOT#2");
        mot_err=1; step(1); chkstate(3'd6, "MOT_ERR");
        if (buzzer!==1'b1 || led[0]!==1'b1 || led[1]!==1'b0) begin
            err=err+1; $display("FAIL mot err outputs buzz=%b led=%b", buzzer, led); end
        else $display("OK   MOT_ERR: led0 kept, buzzer on");
        rst_btn=1; step(1); rst_btn=0; mot_err=0;
        if (err==0) $display("TB_B ALL PASS");
        else        $display("TB_B FAILED err=%0d", err);
        $finish;
    end
endmodule
