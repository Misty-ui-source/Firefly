// =====================================================================
// 模拟题一 参考实现: 智能洗衣机控制器 (先自己做, 卡住再看)
// ★★★ 参数表 ★★★
//  FILL_CYC=3, RINSE_CYC=4, SPIN_CYC=5 : 题面给定的各阶段时长 (clk)
//  WASH 时长 = i_time (轻柔 i_gentle=1 时 x2); i_time 题面限定 1~255,
//      所以时长恒 >=1, 不用像电饭煲那样给 0 值兜底 —— 这是出题时
//      故意收紧的, 考试真题若没写取值范围, 要自己想 0 怎么办
//  BEEP_CYC=3 : 完成关机蜂鸣拍数; STUDENT_ID ★改自己的学号
// ★★★ 状态表 (编码按流程顺序) ★★★
//  IDLE 000 led=0000            i_start=1 -> FILL
//  FILL 001 led=0000            满 3 拍 -> WASH
//  WASH 010 led=flow 流水       满 wash_dur 拍 -> RINSE
//  RINSE 011 led=prog 进度条    满 4 拍 (本拍填满 1111) -> SPIN
//  SPIN 100 led=blink 闪烁      满 5 拍 -> DONE
//  DONE 101 led=1111            i_start=0 -> IDLE (触发蜂鸣模块)
// 设定逻辑: 四个定时阶段共用一个 stay_cnt + 一张时长表 dur,
// 状态机第二段里四个阶段的跳转长得一模一样 (stage_done), 这就是
// "多阶段定时"题的傻瓜结构: 加一个阶段 = 时长表加一行 + 状态加一个
// =====================================================================
module washer_ctrl #(
    parameter [20:0] STUDENT_ID = 21'd0   // ★改: 自己的学号
)(
    input  wire        i_clk,
    input  wire        i_rstn,
    input  wire        i_start,
    input  wire [7:0]  i_time,
    input  wire        i_gentle,
    output reg  [3:0]  o_led,
    output wire        o_buzzer,
    output reg  [20:0] o_print
);
    parameter FILL_CYC = 3;
    parameter RINSE_CYC = 4;
    parameter SPIN_CYC = 5;
    parameter BEEP_CYC = 3;

    localparam [2:0] IDLE = 3'd0, FILL = 3'd1, WASH = 3'd2,
                     RINSE = 3'd3, SPIN = 3'd4, DONE = 3'd5;
    reg [2:0] cur, nxt;

    // ---------- 时长表 + 通用阶段计数 ----------
    wire [31:0] wash_dur = i_gentle ? ({24'd0, i_time} << 1) : {24'd0, i_time};
    reg [31:0] dur;
    always @(*) begin
        case (cur)
            FILL:  dur = FILL_CYC;
            WASH:  dur = wash_dur;
            RINSE: dur = RINSE_CYC;
            SPIN:  dur = SPIN_CYC;
            default: dur = 32'd1;
        endcase
    end
    reg [31:0] stay_cnt;
    wire timed = (cur==FILL) || (cur==WASH) || (cur==RINSE) || (cur==SPIN);
    wire stage_done = timed && (stay_cnt == dur - 1);
    always @(posedge i_clk or negedge i_rstn) begin
        if (!i_rstn)          stay_cnt <= 32'd0;
        else if (nxt != cur)  stay_cnt <= 32'd0;   // 换状态自动清零
        else                  stay_cnt <= stay_cnt + 1'b1;
    end

    // ---------- 三段式 第一段 ----------
    always @(posedge i_clk or negedge i_rstn) begin
        if (!i_rstn) cur <= IDLE;
        else         cur <= nxt;
    end
    // ---------- 三段式 第二段 (照状态表填) ----------
    always @(*) begin
        nxt = cur;
        case (cur)
            IDLE:  if (i_start)    nxt = FILL;
            FILL:  if (stage_done) nxt = WASH;
            WASH:  if (stage_done) nxt = RINSE;
            RINSE: if (stage_done) nxt = SPIN;
            SPIN:  if (stage_done) nxt = DONE;
            DONE:  if (!i_start)   nxt = IDLE;
            default: nxt = IDLE;
        endcase
    end

    // ---------- 数据通路: 三种图案各一份 (流水/进度条/闪烁) ----------
    reg [3:0] flow, prog, blink;
    always @(posedge i_clk or negedge i_rstn) begin
        if (!i_rstn) begin
            flow <= 4'b1000; prog <= 4'b0000; blink <= 4'b1111;
        end else begin
            if (cur != WASH)  flow  <= 4'b1000;
            else              flow  <= {flow[0], flow[3:1]};
            if (cur != RINSE) prog  <= 4'b0000;
            else              prog  <= {1'b1, prog[3:1]};
            if (cur != SPIN)  blink <= 4'b1111;
            else              blink <= ~blink;
        end
    end

    // ---------- 三段式 第三段: 输出选择 ----------
    always @(*) begin
        case (cur)
            WASH:    o_led = flow;
            RINSE:   o_led = prog;
            SPIN:    o_led = blink;
            DONE:    o_led = 4'b1111;
            default: o_led = 4'b0000;   // IDLE, FILL
        endcase
    end

    // ---------- 状态机外: 蜂鸣 3 拍 + 打印 (同电饭煲, 拍数改 3) ----------
    reg beep_busy, buzzer_r;
    reg [31:0] beep_cnt;
    assign o_buzzer = buzzer_r;
    always @(posedge i_clk or negedge i_rstn) begin
        if (!i_rstn) begin
            beep_busy <= 1'b0; beep_cnt <= 32'd0;
            buzzer_r  <= 1'b0; o_print  <= 21'd0;
        end else begin
            if ((cur == IDLE) && i_start) o_print <= 21'd0;
            if ((cur == DONE) && !i_start) begin
                beep_busy <= 1'b1; beep_cnt <= 32'd0; buzzer_r <= 1'b1;
            end else if (beep_busy) begin
                if (beep_cnt == BEEP_CYC-1) begin
                    beep_busy <= 1'b0; buzzer_r <= 1'b0; o_print <= STUDENT_ID;
                end else beep_cnt <= beep_cnt + 1'b1;
            end
        end
    end
endmodule
